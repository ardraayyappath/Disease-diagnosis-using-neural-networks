clear;
clc;
%Dataset
data = [35.5,0,1,0,0,0
35.9,0,0,1,1,1
35.9,0,1,0,0,0
36,0,0,1,1,1
36,0,1,0,0,0
36,0,1,0,0,0
36.2,0,0,1,1,1
36.2,0,1,0,0,0
36.3,0,0,1,1,1
36.6,0,0,1,1,1
36.6,0,0,1,1,1
36.6,0,1,0,0,0
36.6,0,1,0,0,0
36.7,0,0,1,1,1
36.7,0,1,0,0,0
36.7,0,1,0,0,0
36.8,0,0,1,1,1
36.8,0,0,1,1,1
36.9,0,0,1,1,1
36.9,0,1,0,0,0
37,0,0,1,1,0
37,0,0,1,1,0
37,0,1,0,0,0
37,0,0,1,1,1
37,0,0,1,1,1
37,0,0,1,1,1
37,0,0,1,1,1
37,0,0,1,0,0
37.1,0,1,0,0,0
37.1,0,0,1,1,1
37.1,0,0,1,0,0
37.2,0,0,1,1,0
37.2,0,1,0,0,0
37.2,0,0,1,0,0
37.3,0,1,0,0,0
37.3,0,0,1,1,1
37.3,0,0,1,0,0
37.4,0,1,0,0,0
37.4,0,0,1,0,0
37.5,0,0,1,1,0
37.5,0,1,0,0,0
37.5,0,1,0,0,0
37.5,0,0,1,1,1
37.5,0,0,1,0,0
37.5,0,0,1,0,0
37.6,0,0,1,1,0
37.6,0,0,1,1,0
37.6,0,0,1,1,1
37.7,0,0,1,1,0
37.7,0,0,1,1,0
37.7,0,1,0,0,0
37.7,0,0,1,0,0
37.8,0,1,0,0,0
37.8,0,0,1,1,1
37.8,0,0,1,0,0
37.9,0,0,1,1,0
37.9,0,0,1,1,0
37.9,0,1,0,0,0
37.9,0,0,1,1,1
37.9,0,0,1,0,0
38,0,1,1,0,1
38,0,1,1,0,1
38.1,0,1,1,0,1
38.3,0,1,1,0,1
38.5,0,1,1,0,1
38.7,0,1,1,0,1
38.9,0,1,1,0,1
39,0,1,1,0,1
39.4,0,1,1,0,1
39.7,0,1,1,0,1
40,1,1,1,1,1
40,1,1,1,1,1
40,1,1,1,1,0
40,0,0,0,0,0
40,0,0,0,0,0
40,1,1,0,1,0
40,1,1,0,1,0
40,0,1,1,0,1
40.1,1,1,1,1,0
40.2,1,1,1,1,1
40.2,0,0,0,0,0
40.2,1,1,0,1,0
40.3,0,1,1,0,1
40.4,1,1,1,1,1
40.4,1,1,1,1,0
40.4,1,1,1,1,0
40.4,0,0,0,0,0
40.4,1,1,0,1,0
40.5,1,1,1,1,0
40.6,1,1,1,1,1
40.6,0,0,0,0,0
40.6,1,1,0,1,0
40.7,1,1,1,1,1
40.7,1,1,1,1,0
40.7,0,0,0,0,0
40.7,1,1,0,1,0
40.7,0,1,1,0,1
40.8,0,1,1,0,1
40.9,1,1,1,1,0
40.9,1,1,1,1,0
40.9,0,1,1,0,1
41,1,1,1,1,1
41,0,0,0,0,0
41,1,1,0,1,0
41,0,1,1,0,1
41.1,1,1,1,1,1
41.1,1,1,1,1,0
41.1,0,0,0,0,0
41.1,1,1,0,1,0
41.1,0,1,1,0,1
41.2,1,1,1,1,1
41.2,0,0,0,0,0
41.2,1,1,0,1,0
41.2,0,1,1,0,1
41.3,1,1,1,1,0
41.4,0,1,1,0,1
41.5,0,0,0,0,0
41.5,1,1,0,1,0
41.5,0,1,1,0,1
41.5,0,1,1,0,1];
out = [0
1
0
1
0
0
1
0
1
1
1
0
0
1
0
0
1
1
1
0
1
1
0
1
1
1
1
1
0
1
1
1
0
1
0
1
1
0
1
1
0
0
1
1
1
1
1
1
1
1
0
1
0
1
1
1
1
0
1
1
0
0
0
0
0
0
0
0
0
0
1
1
1
0
0
0
0
0
1
1
0
0
0
1
1
1
0
0
1
1
0
0
1
1
0
0
0
0
1
1
0
1
0
0
0
1
1
0
0
0
1
0
0
0
1
0
0
0
0
0];
x = data';
t = out';
% Create Pattern Recognition Network
net = patternnet(20);
net.layers{1}.initFcn = 'initnw';
net.layers{2}.initFcn = 'initnw';
net.initFcn = 'initlay';
% Setup Division of Data for Training, Validation, Testing
net.divideFcn = 'dividerand'; % Dividing data randomly
net.divideMode = 'sample'; % Dividing up every sample
net.divideParam.trainRatio = 40/100;
net.divideParam.valRatio = 30/100;
net.divideParam.testRatio = 30/100;
%Selecting training function
net.trainFcn = 'trainlm'; % Scaled conjugate gradient
net.trainParam.epochs=3000;
net.trainParam.min_grad=10^(-5);
net.trainParam.mu_max=10^10;
% Choose a Performance Function
net.trainParam.max_fail=1000;
net.performFcn = 'mse';
net.layers{1}.transferFcn = 'tansig';
net.layers{2}.transferFcn = 'purelin';
% Choose Plot Functions
net.plotFcns = {'plotperform','plottrainstate','ploterrhist', ...
'plotregression',};
% Train the Network
[net,tr] = train(net,x,t);
% Test the Network
y = net(x);
e = gsubtract(t,y);
tind = vec2ind(t);
yind = vec2ind(y);
percentErrors = sum(tind ~= yind)/numel(tind);
performance = perform(net,t,y)
% Recalculate Training, Validation and Test Performance
trainTargets = t .* tr.trainMask{1};
valTargets = t .* tr.valMask{1};
testTargets = t .* tr.testMask{1};
trainPerformance = perform(net,trainTargets,y);
valPerformance = perform(net,valTargets,y);
testPerformance = perform(net,testTargets,y);
% View the Network
view(net)