Artificial Neural Networks in Medical Diagnosis

Artificial neural networks are finding many uses in the medical diagnosis application. The goal of this project is to evaluate artificial neural network in disease diagnosis. Two cases are studied. The first one is acute nephritis disease; data is the disease symptoms. The second is the heart disease; data is on cardiac Single Proton Emission Computed Tomography (SPECT) images. Each patient classified into two categories: infected and non-infected.

Getting Started

Prerequisites

1) The software used for the training and testing of our Neural Network is MATLAB. We can get it from MathWorks website.

2) MATLAB must have the Neural Network Toolbox installed in order for the project to compile. For getting the Neural Network Toolbox, we use the MATLAB's default tool for downloading and installing libraries automatically.

The DataSet

1) The DataSet was downloaded from the UCI Machine Learning Repository

2) The DataSet was filtered out using C++ code in order to separate our DataSet into Input Data and corresponding Output Data

3) The Input Data and Output Data obtained was directly imported to MATLAB by declaring them as variables in MATLAB

Running the Tests

1) The Total Data was divided into Training Data and Test Data using Ratio to divide them which can be changed to vary results

2) The test runs were handled by the MATLAB Neural Network Toolbox and we further added the plots its supposed to show.

3) The test results were hence plotted and displayed

Built With

1) MATLAB - Mathworks

Authors

Original Paper Author - Qeethara Kadhim Al-Shayea

Developers - Arpit Anshuman, Ardra Ayyappath, Akshat Sharma

Acknowledgements

We thank Prof. Surekha Bhanot Ma'am for her enormous support in helping us learn during the development of this project.
We further extend our support to the Author of the original paper Qeethara Kadhim Al-Shayea without which this project would not have been made possible.